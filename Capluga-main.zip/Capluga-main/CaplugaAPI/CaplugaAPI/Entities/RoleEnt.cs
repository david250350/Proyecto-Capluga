﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CaplugaAPI.Entities
{
    public class RoleEnt
    {
        public long RoleID { get; set; }
        public string RolName { get; set; }
    }
}
